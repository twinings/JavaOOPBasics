package InterfacesAndAbstraction.Car;



public class Main {
    public static void main(String[] args) {
        Car seat = new Seat("Leon", "gray", 110, "Spain");



        System.out.println(seat.toString());
    }

}
