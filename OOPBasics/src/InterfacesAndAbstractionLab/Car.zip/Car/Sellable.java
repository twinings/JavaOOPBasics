package InterfacesAndAbstraction.Car;

public interface Sellable extends Car {
    Double getPrice();
}
