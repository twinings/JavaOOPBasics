package InterfacesAndAbstraction.CarShop;

public interface Car {
    Integer TIRES = 4;

    String getModel();
    String getColor();
    int getHorsePower();
}
