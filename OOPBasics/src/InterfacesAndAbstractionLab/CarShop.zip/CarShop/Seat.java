package InterfacesAndAbstraction.CarShop;

import java.io.Serializable;

public class Seat implements Car,Serializable {
    private String countyProduced;
    private String model;
    private String color;
    private int horsePower;

    public Seat( String model,String color,Integer horsePower,String countyProduced) {
        this.countyProduced = countyProduced;
        this.model = model;
        this.color = color;
        this.horsePower = horsePower;
    }

    @Override
    public int getHorsePower() {
        return this.horsePower;
    }

    @Override
    public String getColor() {
        return this.color;
    }


    @Override
    public String getModel() {
        return this.model;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(String.format(
                "%s is %s color and have %s horse power",
                this.getModel(),
                this.getColor(),
                this.getHorsePower())).append(System.lineSeparator());
      sb.append(String.format("This is %s produced in %s and have %d tires",this.getModel(),this.countyProduced,Car.TIRES)).append(System.lineSeparator());
    return sb.toString();
    }
}
