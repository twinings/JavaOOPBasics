package Inheritance.MordorsCrueltyPlan;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Main {
    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
String[] food = reader.readLine().split(" ");
Gandalf gandalf=new Gandalf();
for(String current:food){
    gandalf.eat(current);
}
        System.out.println(gandalf);

    }
}
