package Inheritance.Animals;

public interface SoundProducible {
    String produceSound();
}
