package Polymorphism.Vehicles;

public abstract class Vehicle {
    private double fuelQuantity;
    private double litersPerKm;


    protected Vehicle(double fuelQuantity, double litersPerKm) {
        this.setFuelQuantity(fuelQuantity);
        this.setLitersPerKm(litersPerKm);
    }
    protected void setFuelQuantity(double fuelQuantity) {

        this.fuelQuantity = fuelQuantity;
    }

    protected final double getFuelQuantity() {
        return fuelQuantity;
    }

    protected double getLitersPerKm() {
        return litersPerKm;
    }


    private void setLitersPerKm(double litersPerKm) {

        this.litersPerKm = litersPerKm;
    }
    public abstract   void drive(double distance);
public abstract  void  refuel(double liters);


}
